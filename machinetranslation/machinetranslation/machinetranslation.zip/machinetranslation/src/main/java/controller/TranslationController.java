package controller;

import model.SupportedDomains;
import model.SupportedLanguages;
import model.TranslationRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.TranslationService;

@RestController
@RequestMapping("/api/translate")
public class TranslationController {

    @Autowired
    private TranslationService translationService;

    @GetMapping("/languages")
    public SupportedLanguages getSupportedLanguages() {
        return translationService.getSupportedLanguages();
    }

    @GetMapping("/domains")
    public SupportedDomains getSupportedDomains() {
        return translationService.getSupportedDomains();
    }

    @PostMapping
    public String translate(@RequestBody TranslationRequest request) {
        return translationService.translate(request);
    }
}
