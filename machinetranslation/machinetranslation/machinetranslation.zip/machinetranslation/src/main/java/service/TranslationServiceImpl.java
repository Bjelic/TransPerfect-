package service;


import model.SupportedDomains;
import model.SupportedLanguages;
import model.TranslationRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class TranslationServiceImpl implements TranslationService{

    @Autowired
    private RestTemplate restTemplate;

    @Value("${translation.api.url}")
    private String apiUrl;


    @Override
    public SupportedLanguages getSupportedLanguages() {
        return restTemplate.getForObject(apiUrl + "languages", SupportedLanguages.class);
    }

    @Override
    public SupportedDomains getSupportedDomains() {
        return restTemplate.getForObject(apiUrl + "domains", SupportedDomains.class);
    }

    @Override
    public String translate(TranslationRequest request) {
        if (request.getContent().split("\\s+").length > 30) {
            throw new IllegalArgumentException("Content exceeds 30 words limit.");
        }
        return restTemplate.postForObject(apiUrl + "translate", request, String.class);
    }
}
