package service;

import model.SupportedDomains;
import model.SupportedLanguages;
import model.TranslationRequest;
import org.springframework.stereotype.Service;

@Service
public interface TranslationService {

    SupportedLanguages getSupportedLanguages();
    SupportedDomains getSupportedDomains();
    String translate(TranslationRequest request);
}
